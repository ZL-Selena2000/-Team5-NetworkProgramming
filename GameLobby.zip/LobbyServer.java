package GameLobby;

import java.io.*;
import java.net.*;
import java.util.*;

public class LobbyServer{
	
	private Socket sock;
	private static ArrayList<Socket> clients = new ArrayList<Socket>(100);
	public static ArrayList<String> users = new ArrayList<String>(100);
	
	public LobbyServer(Socket sock) {
		this.sock = sock;
	}
	
	public static void main(String[] args) throws IOException {
		// ��Ʈ �ѹ� �޾ƿ���
		File serverfile = new File("C:\\Users\\gkqck\\eclipse-workspace\\NetworkTermProject\\src\\GameLobby\\server", "serverInfo.txt");
		BufferedReader br;
		int nPort = 0;
		
 		try {
 			FileReader reader = new FileReader(serverfile);
 			br = new BufferedReader(reader);
 			String portData = br.readLine();
 			nPort = Integer.parseInt(portData.split(" ")[1]);		// ���� ����   PORT: 9999
 		} catch (IOException e) {
 			nPort = 1024;
 		}
 		
 		//���� ����
 		ServerSocket serverSock = new ServerSocket(nPort);
 		System.out.println(nPort + ": ���� ���� ����");
 		
 		while(true) {
 			Socket client = serverSock.accept();
 			clients.add(client);
 			
 			LobbyThread myServer = new LobbyThread(client);
 			myServer.start();
 			
 		}
 		
 		
 		
 		
 	}
}