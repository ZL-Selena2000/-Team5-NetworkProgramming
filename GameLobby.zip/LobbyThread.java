package GameLobby;

import java.io.*;
import java.util.*;
import java.net.*;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class LobbyThread extends Thread {
	static BufferedReader in = null; 
	static BufferedWriter out = null;
	static Socket socket =null;

	Scanner inputstream = null;
	
	public LobbyThread(Socket sock) { 
		this.socket = sock;
	} 
	
	private static void chat() {
		try {
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			String inputMessage;
			while(true) {
				inputMessage = in.readLine();
				if(inputMessage.equalsIgnoreCase("bye")) {
					break;
				}
				out.write(inputMessage + "\n");
				out.flush();
			}
		} catch(IOException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				socket.close();
			} catch (IOException e){
				System.out.println(e + "\n ä�� �� ������ �߻��߽��ϴ�.");
			}
		}
	}
	
	private static void gameStart() {
		try {
			out.write("The game will be started soon.\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() { 
		try {
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			String inputMessage;
			inputMessage = in.readLine();
			
			if(inputMessage.equals("HELLO")) { 
				System.out.println("Client added" + inputMessage); 
				out.write("WELCOME\n");
				out.flush();
			}
			else { 
				System.out.println("WRONG Client added");
				socket.close();
			}

			String PathPointer = "./server";
			File ServerPointer = null;
			Path path = Paths.get(PathPointer); 
 
			if(!Files.exists(path) && !Files.isDirectory(path)) {
				ServerPointer = new File(PathPointer);
				ServerPointer.mkdir();
			}  
			
			PathPointer = "./server/users";
			path = Paths.get(PathPointer);

			if(!Files.exists(path) && !Files.isDirectory(path)) {
				ServerPointer = new File(PathPointer);
				ServerPointer.mkdir();
			}  
  
 
			while(true) {
				inputMessage = in.readLine();
				String outputMessage =null;
				
				outputMessage = String.valueOf(inputMessage); 
				String token[] = inputMessage.split(" "); 
				System.out.println(inputMessage+ "Connected!");

				out.write(inputMessage+"\n");
				out.flush();
				if(inputMessage.equalsIgnoreCase("0")) {
					break;
				}
				else if(inputMessage.equals("1")) {
					inputMessage = in.readLine();
					String ID = inputMessage;
					path = Paths.get(PathPointer+"/"+inputMessage);
					System.out.println(path +" "+ Files.exists(path)+ inputMessage);
					if(!Files.exists(path)) {  
						out.write("There is no data."+"\n");
						out.flush();  
					} 
					else {
						BufferedReader reader = Files.newBufferedReader(path);
						String line = reader.readLine();
						out.write(line + "\n");
						out.write("\nIf you want to chat with " + ID + ", enter \"Chat\"\nIf you want to start a game with " + ID + ", enter \"Start\"\n");
						inputMessage = in.readLine();
						
						if(inputMessage.equalsIgnoreCase("Chat")) {
							System.out.println("Start Chat with " + ID);
							LobbyThread.chat();
						}
						else if(inputMessage.equalsIgnoreCase("Start")) {
							out.write("Are You Ready? Y/N\n");
							inputMessage = in.readLine();
							if(inputMessage.equalsIgnoreCase("Y")) {
								LobbyThread.gameStart();
							}
						}
					}
				}
			} 
		}catch(Exception e){ 
			e.printStackTrace();
		}finally{ 
			System.out.println("Client quited");
			try { 
				socket.close(); 
			}catch(IOException e) { 
				e.printStackTrace(); 
			}	
		}

	}

	
} 
 
