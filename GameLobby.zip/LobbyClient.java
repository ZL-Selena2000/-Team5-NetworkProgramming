package GameLobby;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class LobbyClient {

	public static void main(String[] args) {
		
		BufferedReader in = null; 
		BufferedReader stin = null;
		BufferedWriter out = null;
 
		Socket socket =null; 
		String serverIP=null;
		int nPort =0;
		int cnt = 0;
		
		File serverfile = new File("C:\\Users\\gkqck\\eclipse-workspace\\NetworkTermProject\\src\\GameLobby\\server", "serverInfo.txt");
		BufferedReader br;

 		try {
 			FileReader reader = new FileReader(serverfile);
 			br = new BufferedReader(reader);
 			String Data = br.readLine();
 			
 			while(Data != null) {
 				if(cnt == 0) {
 					nPort = Integer.parseInt(Data.split(" ")[1]);		// ���� ����   PORT: 9999
 					cnt++;
 				}
 				else if(cnt == 1) {
 					serverIP = Data.split(" ")[1];
 				}
 				Data = br.readLine();
 			}
 			
 		} catch (Exception e) {
 			serverIP=  "localhost";
 			nPort = 1024;
 		}
 		
 		System.out.println(nPort + "\n" + serverIP);
		  
		try {
			socket = new Socket(serverIP,nPort);
			
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			stin = new BufferedReader(new InputStreamReader(System.in));
			out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			String inputMessage = null;
	
			String outputMessage;

			out.write("HELLO\n");
			out.flush();
			inputMessage = in.readLine();
			
			if(inputMessage.equals("WELCOME")) {
				System.out.println("Welcome!\n0)Leave\n1)Profile");
				
			}
			else { 
				System.out.println("ERROR: The server is Wrong. ");
				socket.close();
			}
			
			while(true) {
				outputMessage = stin.readLine();
				System.out.println(outputMessage +" Sended");   
				out.write(outputMessage+"\n");
				out.flush();
				
				System.out.println(" waitting for response...");   
				inputMessage = in.readLine();  
				System.out.println(inputMessage +" responsed by server");    
				
				if(inputMessage.equals("0")) { 
					break; 
				}
				else if(inputMessage.equals("1")) {
					outputMessage = stin.readLine();
					System.out.println(outputMessage +" as ID Sended");  // ID Send
					out.write(outputMessage+"\n");  // CODE and Messages
					out.flush();
					
					inputMessage = in.readLine(); // wait server to ready instruction
					System.out.println(inputMessage +" received to server.");  
					
					if(inputMessage.equalsIgnoreCase("ENID")) {
						System.out.println(inputMessage +" ERROR : NO ID exists. ");   
					} 
					else if(inputMessage.equals("CRID")) {
						System.out.println(inputMessage +" : ID exists. Enter PW  "); 
						
						outputMessage = stin.readLine();
						System.out.println(outputMessage +" as PW Sended");   
						out.write(inputMessage+" "+outputMessage+"\n");   
						out.flush();
						inputMessage = in.readLine();  
						System.out.println(inputMessage +" received to server.");  
					} 
					
					String token[] = inputMessage.split(" ");
					if(token[0].equals("LEND")) {
					 	System.out.println(token[1]+" received: Login complete.");  
					}
				}
				else if(inputMessage.equals("2")) {
					System.out.println(inputMessage +" received: Send ID ");  
					outputMessage = stin.readLine();
					System.out.println(outputMessage +" Sended");  
					out.write(outputMessage+"\n");
					out.flush(); 
					inputMessage = in.readLine(); // wait server to ready instruction
					System.out.println(inputMessage +" received");  
					if(inputMessage.equals("EIDE")) {	 
						// If Using GUI, We should change it to button...
						System.out.println("Error : Same ID already exists.");   
					}
					else {// ID created, so PW Need to be created.
						inputMessage = stin.readLine();
						System.out.println(inputMessage +" Sended");  
						out.write("PW:"+inputMessage+"\n");
						out.flush(); 
						inputMessage = in.readLine(); // wait server to ready instruction
						System.out.println(inputMessage +" received");  
						// ... like this, repeat until required data received. after this, send this. 
						out.write("CIIE\n"); // completed Inserting Inputs Ended
						out.flush();
					}
				}
			}
		} catch (IOException e) { 
		} finally {
			try {
				socket.close(); 
			} catch (Exception e) {
				System.out.println("Error: Currently server hasn't opened / or having connection problem. check your IP address. ");
			}
		}
	}
}
